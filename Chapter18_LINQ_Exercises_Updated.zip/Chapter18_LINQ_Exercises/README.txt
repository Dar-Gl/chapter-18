Murach C# Chapter 18 exercises

Exercise18-1_Query: LINQ query expression with join, filter and descending date sort.
Exercise18-2_Method: Equivalent LINQ method-based query.

Open either CustomerInvoices.csproj in Visual Studio on Windows.
Required original textbook data files were NOT uploaded:
  C:\C#\Files\Invoices.txt
  C:\C#\Files\Customers18.txt
The supplied InvoiceDB.cs and CustomerDB.cs expect those exact paths.
No sample data was invented. Copy your textbook data files there to run.
Requires a compatible .NET Windows desktop SDK; project targets net7.0-windows.
The form UI was reconstructed because designer files were not uploaded.

Additional original Visual Studio files included:
- frmCustomerInvoices.resx
- CustomerInvoices.csproj.user (form designer display setting)

The original form designer .Designer.cs and data .txt files were not provided.
The included forms use programmatic layout; they are not pixel-identical to the textbook figure.
Build/run has not been verified on Windows.

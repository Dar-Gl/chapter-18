namespace CustomerInvoices;

public partial class frmCustomerInvoices : Form
{
    private readonly ListView lvInvoices = new();
    private readonly TextBox txtMinimum = new();
    private readonly Button btnFilter = new();
    private readonly Label lblMinimum = new();
    private List<Invoice> invoices = new();
    private List<Customer> customers = new();

    public frmCustomerInvoices()
    {
        InitializeComponent();
        Load += frmCustomerInvoices_Load;
    }

    private void InitializeComponent()
    {
        Text = "Customer Invoices";
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(1020, 530);
        MinimumSize = new Size(800, 400);

        lblMinimum.Text = "Minimum invoice total:";
        lblMinimum.SetBounds(15, 17, 145, 25);
        txtMinimum.SetBounds(165, 15, 110, 26);
        txtMinimum.Text = "0";
        btnFilter.Text = "Apply filter";
        btnFilter.SetBounds(290, 14, 110, 29);
        btnFilter.Click += (_, _) => DisplayInvoices();

        lvInvoices.SetBounds(15, 55, 990, 455);
        lvInvoices.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        lvInvoices.View = View.Details;
        lvInvoices.FullRowSelect = true;
        lvInvoices.GridLines = true;
        lvInvoices.Columns.Add("Invoice ID", 90);
        lvInvoices.Columns.Add("Date", 105);
        lvInvoices.Columns.Add("Customer", 220);
        lvInvoices.Columns.Add("Product total", 125);
        lvInvoices.Columns.Add("Sales tax", 110);
        lvInvoices.Columns.Add("Shipping", 110);
        lvInvoices.Columns.Add("Invoice total", 125);

        Controls.AddRange(new Control[] { lblMinimum, txtMinimum, btnFilter, lvInvoices });
    }

    private void frmCustomerInvoices_Load(object? sender, EventArgs e)
    {
        try
        {
            invoices = InvoiceDB.GetInvoices();
            customers = CustomerDB.GetCustomers();
            DisplayInvoices();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Unable to load invoice/customer data.\n" +
                "Place Invoices.txt and Customers18.txt in C:\\C#\\Files\\, " +
                "or update the paths in InvoiceDB.cs and CustomerDB.cs.\n\n" +
                ex.Message, "Data file error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void DisplayInvoices()
    {
        if (!decimal.TryParse(txtMinimum.Text, out decimal minimum))
        {
            MessageBox.Show("Enter a valid minimum invoice total.");
            txtMinimum.Focus();
            return;
        }

        var results = invoices
                .Join(customers,
                    invoice => invoice.CustomerID,
                    customer => customer.CustomerID,
                    (invoice, customer) => new { invoice, customer })
                .Where(x => x.invoice.InvoiceTotal >= minimum)
                .OrderByDescending(x => x.invoice.InvoiceDate)
                .Select(x => new
                {
                    x.invoice.InvoiceID,
                    x.invoice.InvoiceDate,
                    Customer = x.customer.Name,
                    x.invoice.ProductTotal,
                    x.invoice.SalesTax,
                    x.invoice.Shipping,
                    x.invoice.InvoiceTotal
                });

        lvInvoices.BeginUpdate();
        try
        {
            lvInvoices.Items.Clear();
            foreach (var item in results)
            {
                ListViewItem row = new(item.InvoiceID.ToString());
                row.SubItems.Add(item.InvoiceDate.ToShortDateString());
                row.SubItems.Add(item.Customer);
                row.SubItems.Add(item.ProductTotal.ToString("c"));
                row.SubItems.Add(item.SalesTax.ToString("c"));
                row.SubItems.Add(item.Shipping.ToString("c"));
                row.SubItems.Add(item.InvoiceTotal.ToString("c"));
                lvInvoices.Items.Add(row);
            }
        }
        finally { lvInvoices.EndUpdate(); }
    }
}
